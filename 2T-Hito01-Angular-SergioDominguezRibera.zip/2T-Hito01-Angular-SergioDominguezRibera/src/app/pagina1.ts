export class Pagina1 {
    nombre: string;
    apellido: string ;
  }