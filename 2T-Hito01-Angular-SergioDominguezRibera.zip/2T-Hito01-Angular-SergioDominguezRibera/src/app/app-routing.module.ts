import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InicioComponent } from './inicio/inicio.component';
import { EstudiantesComponent } from './estudiantes/estudiantes.component';
import { AsignaturasComponent } from './asignaturas/asignaturas.component';

import { Pagina1Component } from './pagina1/pagina1.component';
import { Pagina2Component } from './pagina2/pagina2.component';
import { Pagina3Component } from './pagina3/pagina3.component';
import { Pagina4Component } from './pagina4/pagina4.component';

const routes: Routes = [
  { path: '', redirectTo: 'inicio', pathMatch: 'full' },
  { path: 'inicio', component: InicioComponent },
  { path: 'estudiantes', component: EstudiantesComponent },
  { path: 'asignaturas', component: AsignaturasComponent },
  { path: 'pag1', component: Pagina1Component },
  { path: 'pag2', component: Pagina2Component },
  { path: 'pag3', component: Pagina3Component },
  { path: 'pag4', component: Pagina4Component },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
