export class Estudiante {
  nombre: string;
  apellido: string ;
  genero: string;
}
