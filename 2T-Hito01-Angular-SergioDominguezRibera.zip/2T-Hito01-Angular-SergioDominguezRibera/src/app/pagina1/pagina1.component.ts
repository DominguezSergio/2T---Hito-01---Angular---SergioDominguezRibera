import { Component, OnInit } from '@angular/core';
import { Pagina1 } from '../pagina1';

@Component({
  selector: 'app-pagina1',
  templateUrl: './pagina1.component.html',
  styleUrls: ['./pagina1.component.css']
})
export class Pagina1Component implements OnInit {
  index:number = 2;
  nombre:string;
  apellido:string;
  nombres:string[] = [
    'Susana',
    'Juan'
  ]
  apellidos:string[] = [
    'Mercolan',
    'Albrecht'
  ]

  constructor() { 
    
  }
  addRecord() {
    this.index = this.index + 1;
    this.nombres.push(this.nombre);
    this.apellidos.push(this.apellido);
    console.log(this.nombre);
    console.log(this.nombres);
    console.log(this.apellido);
    console.log(this.apellidos);
  }
  borrar(){
    this.nombres.splice(this.nombres.length - 1);
    this.apellidos.splice(this.apellidos.length - 1);
  }

  ngOnInit() {
  }

}
